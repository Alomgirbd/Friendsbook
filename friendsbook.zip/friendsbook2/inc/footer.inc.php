			<div class="footer">
				<div class="f_menu">
					<a href="#" class="f_menu2" >|  About  |</a>
					<a href="#" class="f_menu2" >|  Help  |</a>
					<a href="http://alomgir.cmtmapi.com/" class="f_menu2" >|  Developer  |</a>
					<a style="color:#088A08; text-decoration: none">| Md. Alomgir hossain => developed: 2019  |</a>
				</div>
			</div>
		</div>
	</body>
</html>