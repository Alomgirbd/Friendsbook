<div style="text-align: center; padding: 10px 0 0 0px;">
		<a href="#" style="text-decoration: none; color: #7C7979;" >  About  -</a>
		<a href="#" style="text-decoration: none; color: #7C7979;" >Help  -</a>
		<a href="http://alomgir.cmtmapi.com/" class="f_menu2" >|  Developer  |</a>
	<p href="#" style="text-align: center; padding: 10px 0px;">Md. Alomgir hossain |developed: 2019 </p>
</div>
