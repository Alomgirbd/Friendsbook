<?php 
 include ( "inc/connect.inc.php");
ob_start();
session_start();
if (!isset($_SESSION['user_login'])) {
	header('location: signin.php');
}
else {
	$user = $_SESSION['user_login'];
}
 //showmore for profile home post
 $friendsbookhmlastid = $_REQUEST['friendsbookhmlastid'];
 if (isset($friendsbookhmlastid)) {
 	$friendsbookhmlastid = $_REQUEST['friendsbookhmlastid'];
 }else {
 	header("location: index.php");
 }
 if ($friendsbookhmlastid >= 1) {
 			//getting username
		 $result = mysql_query("SELECT * FROM posts WHERE id ='$friendsbookhmlastid'") or die(mysql_error());
		 $name = mysql_fetch_assoc($result);
		 $username = $name['added_by'];
		//timeline query table
		$getposts = mysql_query("SELECT * FROM friendsbook WHERE added_by ='$username' AND friendsbook_give !='0' AND id < $friendsbookhmlastid ORDER BY id DESC LIMIT 7") or die(mysql_error());
		if (mysql_num_rows($getposts)) {
			while ($row = mysql_fetch_assoc($getposts)) {
			include ( "./inc/newsfeed.inc.php" );
			$friendsbookhmlastvalue = $row['id'];
		}
			echo '<br><li class="getmore" id="'.$friendsbookhmlastvalue.'" >Show More</li>';
		}else {
			echo '<li class="nomorepost">Opps! Nothing more found.</li>';
	}
 }
?>