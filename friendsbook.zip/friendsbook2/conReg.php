<?php include ( "./inc/connect.inc.php" ); ?>

<!DOCTYPE html>
<html>
<head>
	<title>Confirm Registration</title>
	<link rel="icon" href="./img/title.png" type="image/x-icon">
	<meta charset="uft-8">
	<link rel="stylesheet" type="text/css" href="./css/style.css">
</head>
<body>

<div>
	<div><?php include ( "./inc/login.inc.php" ); ?></div>
	<div class="succReg">
		<p>Welcome Friends</p><br><br>
		<h1>Registration successfull. Nowadays Friendsbook.com is free for well known </h1>
		<h1>Within 12 hours confirmation email send to you .</h1>
	</div>
	<div><?php include ( "./inc/footer.inc.php"); ?></div>
</div>

</body>
</html>
