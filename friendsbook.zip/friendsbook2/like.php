<?php include ( "./inc/connect.inc.php"); ?>
<?php  
ob_start();
session_start();
if (!isset($_SESSION['user_login'])) {
	header('location: signin.php');
}
else {
	$user = $_SESSION['user_login'];
}

//inserting friendsbook  like
if (isset($_REQUEST['did'])) {
	$friendsbook_id = $_REQUEST['did'];

	$insertfriendsbooklike = mysql_query("INSERT INTO friendsbook_likes VALUES ('','$user','$friendsbook_id')");
	header("location: index.php");
}else {
	header('location: index.php');
}

//deleting friendsbook like
if (isset($_REQUEST['udid'])) {
	$friendsbook_uid = $_REQUEST['udid'];

	$del_friendsbooklike = mysql_query("DELETE FROM friendsbook_likes WHERE friendsbook_id='$friendsbook_uid'");
	header("location: index.php");
}else {
	header('location: index.php');
}
//inserting post like
if (isset($_REQUEST['pid'])) {
	$post_id = $_REQUEST['pid'];

	$insertPostlike = mysql_query("INSERT INTO post_likes VALUES ('','$user','$post_id')");
	header("location: newsfeed.php");
}else {
	header('location: newsfeed.php');
}

//deleting post like
if (isset($_REQUEST['upid'])) {
	$post_uid = $_REQUEST['upid'];

	$del_postlike = mysql_query("DELETE FROM post_likes WHERE post_id='$post_uid'");
	header("location: newsfeed.php");
}else {
	header('location: newsfeed.php');
}

?>