<?php 
mysql_connect("localhost","root","") or die("Couldn't connet to SQL server");
mysql_select_db("friendsbook") or die("Couldn't select DB");
 ?>
