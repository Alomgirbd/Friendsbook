<?php include ( "./inc/connect.inc.php"); ?>
<?php  
ob_start();
session_start();
if (!isset($_SESSION['user_login'])) {
	header('location: signin.php');
}
else {
	$user = $_SESSION['user_login'];
	
	//inserting friendsbook  like
	if (isset($_REQUEST['did'])) {
		$friendsbook_id = $_REQUEST['did'];
	
		$insertfriendsbooklike = mysql_query("INSERT INTO friendsbook_likes VALUES ('','$user','$friendsbook_id')");
		header("location: index.php");
	}else {
		header('location: index.php');
	}
}

?>